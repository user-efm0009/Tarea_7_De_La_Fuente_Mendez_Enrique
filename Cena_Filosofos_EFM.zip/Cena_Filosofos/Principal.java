package Cena_Filosofos;

import java.util.concurrent.Semaphore;

public class Principal {

    public static void main(String[] args) {

        // ARRAY DE NUMEROS PARA GUARDAR LOS 5 PALILLOS

        int n = 5;
        Palillo[] palillos = new Palillo[n];

        // BUCLE FOR PARA IR INICIALIZANDO LA POSICION DE CADA PALILLO EN EL ARRAY

        for (int i = 0; i < n; i++) {

            palillos[i] = new Palillo(i + 1);

        }

        // BUCLE FOR PARA IR GENERANDO A CADA FILOSOFO CON SUS 2 PALILLOS

        for (int i = 0; i < n; i++) {

            Palillo izq = palillos[i];
            Palillo der = palillos[(i + 1) % n];
            new Thread (new Filosofo(i + 1, izq, der)).start();

        }

    }

}


