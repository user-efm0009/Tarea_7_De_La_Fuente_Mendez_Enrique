package Cena_Filosofos;

public class Filosofo implements Runnable {

    // ATRIBUTOS PRIVADOS

    private int id;
    private Palillo palilloIzq;
    private Palillo palilloDer;

    // CONSTRUCTOR COMPLETO

    public Filosofo (int id, Palillo izq, Palillo der) {

        this.id = id;
        this.palilloIzq = izq;
        this.palilloDer = der;

    }

    // METODO RUN SOBREESCRITO (OVERRIDE)

    @Override
    public void run() {

        try {

            while (true) {

                pensar();
                System.out.println("El filosofo " + id + " intenta comer");

                // IMPEDIMENTO DEL INTERBLOQUEO

                if (id == 5) {

                    palilloDer.coger();
                    palilloIzq.coger();

                } else {

                    palilloIzq.coger();
                    palilloDer.coger();

                }

                comer(); // ACCION PARA COMER

                // ACCIONES PARA CUANDO TERMINE DE COMER

                palilloIzq.soltar();
                palilloDer.soltar();
                System.out.println("El filosofo " + id + " ha terminado de comer");

            }

            // EXCEPCION THREAD

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

        }

    }

    // METODO PARA QUE UN FILOSOFO PIENSE

    private void pensar() throws InterruptedException {

        System.out.println("El filosofo " + id + " se encuentra pensando");

        // ACCION PARA DORMIR EL HILO. EL TIEMPO SERA A TRAVES DE UN RANDOM
        // Y ESE NUMERO ALEATORIO SE MULTIPLICARA POR 1000
        Thread.sleep((long)(Math.random() * 1000));

    }

    // METODO PARA QUE UN FILOSOFO COMA

    private void comer() throws InterruptedException {

        System.out.println("El filosofo " + id + " se encuentra comiendo");
        Thread.sleep((long)(Math.random() * 1000));

    }

}

