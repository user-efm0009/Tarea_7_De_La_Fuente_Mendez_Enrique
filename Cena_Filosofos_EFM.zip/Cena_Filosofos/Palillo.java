package Cena_Filosofos;

import java.util.concurrent.Semaphore;

public class Palillo {

    // ATRIBUTOS PRIVADOS

    private final Semaphore semaforo = new Semaphore(1);
    private final int id;

    // CONSTRUCTOR COMPLETO

    public Palillo (int id) {

        this.id = id;

    }

    // METODO PARA QUE UN PALILLO SEA COGIDO

    public void coger() throws InterruptedException {

        semaforo.acquire();
        System.out.println("El palillo " + id + " ha sido cogido");

    }

    // METODO PARA QUE UN PALILLO SE LIBERE

    public void soltar() {

        semaforo.release();
        System.out.println("El palillo " + id + " ha sido liberado");

    }

}

